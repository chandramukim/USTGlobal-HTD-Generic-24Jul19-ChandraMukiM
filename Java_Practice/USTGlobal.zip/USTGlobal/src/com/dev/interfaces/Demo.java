package com.dev.interfaces;

public class Demo implements B, A{
	@Override
	public void m1() {
		
	}
}
