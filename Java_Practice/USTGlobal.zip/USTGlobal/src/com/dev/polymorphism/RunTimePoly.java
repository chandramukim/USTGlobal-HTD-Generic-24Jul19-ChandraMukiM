package com.dev.polymorphism;

public class RunTimePoly {
	
	static String lastName = "Muki";
	
	public void print() {
		String firstName = "Chandra";
		System.out.println("NAME: "+firstName+" "+lastName);
	}
	
	public static void main(String[] args) {
		RunTimePoly rtp = new RunTimePoly();
		rtp.print();
	}
}
