package com.dev.interfaces;

public interface B extends A {
	@Override
	default void m1() {
		System.out.println("hi");
	}
	
}
