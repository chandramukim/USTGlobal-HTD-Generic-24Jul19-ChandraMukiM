package com.dev.inheritance;

public class Super_Class {

	public Super_Class() {
		System.out.println("no-argument constructor");
	}
	
	public Super_Class(int i) {
		System.out.println("int argument constructor");
	}
	
	public Super_Class(String s) {
		System.out.println("String argument constructor");
	}
	
	public static void main(String[] args) {
		 //Super_Class sc = new  Super_Class("n");
	}

}
