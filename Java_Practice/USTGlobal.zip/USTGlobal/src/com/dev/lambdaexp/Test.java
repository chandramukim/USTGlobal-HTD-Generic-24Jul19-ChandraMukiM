package com.dev.lambdaexp;

public class Test {
	public static void main(String[] args) {
		FuncInt f = () -> {
			for(int i = 1; i<=10; i++) {
				System.out.println(i);
			}
		};
		f.display();
		
		FuncInt f1 = () -> System.out.println("Hello");
		f1.display();
		
		FuncInt f2 = () -> {
			try {
				int i = 10/0;
				System.out.println(i);
			}catch(Exception e) {
				System.out.println("Exception Occured!!!!");
			}
		};
		f2.display();
		
		FuncInt1 fi = (int i) -> {
			for(int j=1; j<=i; j++) {
				System.out.println(j);
			}
		};
		fi.display(5);
		
		
		
	}
}
