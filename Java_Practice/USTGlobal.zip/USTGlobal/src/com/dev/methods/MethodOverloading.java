package com.dev.methods;

public class MethodOverloading {
	
	static MethodOverloading mo = new MethodOverloading();
	
	//it is possible to overload static,final and private methods
	public static void print() {
		System.out.println("Running no-arg print()");
	}
	
	private int print(int i) {
		System.out.println("Running int arg print()");
		return 10;
	}
	
	final String print(String s) {
		System.out.println("Running String arg print()");
		return s;
	}
	
	
	public static void main(String[] args) {
		
		mo.print("Maya");
		mo.print(10);
		mo.print();
	}
}
