package com.dev.collection;

import java.util.TreeSet;

public class C5 {
	public static void main(String[] args) {
		TreeSet<Employee> ts = new TreeSet<Employee>();
		
		Employee e = new Employee();
		e.setName("Muki");
		e.setId(101);
		e.setEmail("muki123@gmail.com");
		e.setPassword("muki1998");
		
		
		Employee e1 = new Employee();
		e1.setName("Maya");
		e1.setId(102);
		e1.setEmail("maya9876@gmail.com");
		e1.setPassword("maya1999");
		e1.setSalary(30000);
		
		Employee e2 = new Employee();
		e2.setName("Neelu");
		e2.setId(103);
		e2.setEmail("neelu678@gmail.com");
		e2.setPassword("neelu123");
		e2.setSalary(40000);
		
		ts.add(e);
		ts.add(e1);
		ts.add(e2);
		
		System.out.println(ts);

	}
}
