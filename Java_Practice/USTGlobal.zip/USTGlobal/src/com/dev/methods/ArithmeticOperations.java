package com.dev.methods;

public class ArithmeticOperations {
	
	static ArithmeticOperations ao = new ArithmeticOperations();
	
	//Overloading add() method
	public int add(int a,int b) {
		return (a+b);
	}
	
	public int add(int a,int b,int c) {
		return (a+b+c);
	}
	
	public int add(int a,int b,int c,int d) {
		return (a+b+c+d);
	}
	
	//Overlaoded sub() method
	public int sub(int a, int b) {
		return (a-b);
	}	
	
	public int sub(int a,int b,int c) {
		return (a-b-c);
	}
	
	public int sub(int a,int b,int c,int d) {
		return (a-b-c-d);
	}
	
	//Overloaded mul() method
	public int mul(int a,int b) {
		return (a*b);
	}
	
	public int mul(int a,int b,int c) {
		return (a*b*c);
	}
	
	public int mul(int a,int b,int c,int d) {
		return (a*b*c*d);
	}
	
	//Overloaded div() method
	public double div(int a,int b) {
		return (a/b);
	}
	
//	public double div(int a,int b,int c) {
//		return (a/b/c);
//	}
	
	public double div(int a,int b,int c,int d) {
		return (a/b/c/d);
	}
	
	//main() method
	public static void main(String[] args) {
		System.out.println("Addition of two,three and four numbers simultaneously");
		System.out.println(ao.add(10,20));
		System.out.println(ao.add(10,20,30));
		System.out.println(ao.add(10, 20, 30, 40));
		
		System.out.println();
		
		System.out.println("Substraction of two,three and four numbers simultaneously");
		System.out.println(ao.sub(50, 40));
		System.out.println(ao.sub(40, 30,20));
		System.out.println(ao.sub(60, 50, 40, 30));
		
		System.out.println();
		
		System.out.println("Multiplication of two,three and four numbers simultaneously");
		System.out.println(ao.mul(1,2));
		System.out.println(ao.mul(3,4,5));
		System.out.println(ao.mul(3, 6, 7, 2));
		
		System.out.println();
		
		System.out.println("Division of two,three and four numbers simultaneously");
		System.out.println(ao.div(200, 100));
		System.out.println(ao.div(1,1,1,1));
		
		
		
	}

}
