package com.dev.collection;

import java.util.HashSet;

public class C2 {
	public static void main(String[] args) {
		HashSet<Employee> hs = new HashSet<Employee>();
	
		//setting first employee details
		Employee e = new Employee();
		e.setName("Muki");
		e.setId(101);
		e.setEmail("muki123@gmail.com");
		e.setPassword("muki1998");
		
		//setting second employee details
		Employee e1 = new Employee();
		e1.setName("Maya");
		e1.setId(102);
		e1.setEmail("maya9876@gmail.com");
		e1.setPassword("maya1999");
		
		//setting third employee details
		Employee e2 = new Employee();
		e2.setName("Neelu");
		e2.setId(103);
		e2.setEmail("neelu678@gmail.com");
		e2.setPassword("neelu123");
		
		
		System.out.println("Output of add(): "+hs.add(e)+" "+hs.add(e1)+" "+hs.add(e2));
		System.out.println();
		System.out.println(hs);
		System.out.println();
		
		//updating email
		e.setEmail("muki1998@gmail.com");
		e1.setEmail("maya1999@gmail.com");
		e2.setEmail("neelu1997@gmial.com");

		System.out.println("After updating email");
		System.out.println(hs);
		System.out.println();
		
		//deleting e2
		hs.remove(e2);
		System.out.println(hs);
		
	}
}
