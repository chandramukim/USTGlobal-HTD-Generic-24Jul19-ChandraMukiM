package com.dev.abstraction;

public class Dogs {

	final static int I = 100;
	public static void main(String[] args) {
			System.out.println(I);
//		a = 20;
//		cannot be re-initialized
		
		
	}
}
