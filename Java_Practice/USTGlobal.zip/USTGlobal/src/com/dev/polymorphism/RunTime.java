package com.dev.polymorphism;

public class RunTime extends RunTimePoly {
	
	static String firstName = "Maya";

	@Override
	public void print() {
		//String firstName = "chandra";
		System.out.println("NAME : "+this.firstName+" "+super.lastName);
	}
	
	public static void main(String[] args) {
		RunTime rt = new RunTime();
		rt.print();
	}

}
