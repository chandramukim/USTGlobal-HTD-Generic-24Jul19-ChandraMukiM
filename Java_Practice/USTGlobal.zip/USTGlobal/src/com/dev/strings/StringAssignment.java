package com.dev.strings;

public class StringAssignment {
	public static void main(String[] args) {
		String str = "Welocome to Bangalore";
		//str= "Welcome to Bangalore";
		String str1 = str;
		StringAssignment sa = new StringAssignment();
		
		for(int i=0; i<str.length();i++) {
			char[] ch = str.toCharArray();
			System.out.println(ch[i]);
		}
		
	
		char ch = str.charAt(8);
		System.out.println(ch);
		
		boolean b = str.equals(str);
		System.out.println(b);
	
		boolean bool = str.equalsIgnoreCase(str);
		System.out.println(bool);
		System.out.println(str.getClass());
		System.out.println(str.toString());
		System.out.println(str.hashCode());
		System.out.println(str.equals(sa));
	}

}
