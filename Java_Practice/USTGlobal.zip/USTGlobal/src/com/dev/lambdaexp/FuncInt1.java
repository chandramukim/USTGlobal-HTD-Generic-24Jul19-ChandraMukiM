package com.dev.lambdaexp;

public interface FuncInt1 {
	public void display(int i);
}
