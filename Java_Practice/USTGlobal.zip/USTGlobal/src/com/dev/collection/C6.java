package com.dev.collection;

import java.util.ArrayList;

import com.dev.encapsulation.Dogs;

public class C6 {
	public static void main(String[] args) {
		ArrayList<Dogs> arl = new ArrayList<Dogs>(1);
		
		Dogs d = new Dogs();
		d.setAge(1);
		d.setBreed("husky");
		d.setColor("White");
		d.setName("Shiro");		
		
		Dogs d1 = new Dogs();
		d1.setAge(2);
		d1.setBreed("dalmation");
		d1.setColor("Black&White");
		
		arl.add(d);
		arl.add(d1);
		
		System.out.println(arl);
	}
}
