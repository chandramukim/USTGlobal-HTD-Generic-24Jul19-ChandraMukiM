package com.dev.methods;

public class ChildClass extends ParentClass{
	ChildClass(int b){
		super.a = b;
		
	}
	
	static ChildClass cc = new ChildClass(10);
	public static void main(String[] args) {
		cc.print();
	}
	
	
	// if this method is declared as private in parent class then it can't be override here
	@Override
	public void print() {
		String college="ACE";
		super.print();
		System.out.println(" A graduate from "+college);
		System.out.println(a);

	}

}
