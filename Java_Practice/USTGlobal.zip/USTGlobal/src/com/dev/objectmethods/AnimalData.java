package com.dev.objectmethods;

public class AnimalData {
	
	public static void main(String[] args) {
		//for Dogs
		Dogs d = new Dogs();
		Dogs d1 = new Dogs();
		Dogs d2 = new Dogs();
		
		//setting the values
		d.setAge(1);
		d.setBreed("Husky");
		d.setColor("White&Brown");
		d.setName("Scooby");		
	
		
		//setting the values
		d1.setAge(2);
		d1.setBreed("Pit bull");
		d1.setColor("Grey");
		d1.setName("Spike");
		
		d2.setAge(2);
		d2.setBreed("Pit bull");
		d2.setColor("Grey");
		d2.setName("Spike");
				
		Dogs[] dog = {d,d1,d2};
		
		
		for(int i=0;i<dog.length;i++) {
//			System.out.println("Name :"+dog[i].getName());
//			System.out.println("Age :"+dog[i].getAge());
//			System.out.println("Breed :"+dog[i].getBreed());
//			System.out.println("Color :"+dog[i].getColor());
			System.out.println(dog[i]);
			System.out.println("==============================");
		}
		
		System.out.println(d.equals(d1));
		System.out.println(d1.equals(d2));
		System.out.println(d.hashCode());
		

	}
}
