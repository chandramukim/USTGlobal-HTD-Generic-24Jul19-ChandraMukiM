package com.dev.abstraction;

public class Sphere extends Circle{
	
	@Override
	void draw() {
		System.out.println("Running draw() of Sphere class");
	}

}
