package com.dev.inheritance;

public class Sub_Class extends Super_Class {

	public Sub_Class() {
		super("maya");
	}
	
	public Sub_Class(int i) {
		super();
	}
	
	public  Sub_Class(String s) {
		super(12);
		
	}
	
	public static void main(String[] args) {
		 Sub_Class sc = new  Sub_Class();
	}
}
