package com.dev.methods;

public class MethodExample {
	static MethodExample me = new MethodExample();
	static int areaAll = 0;
	
	public static void main(String[] args) {
		
		int area = calcArea(6);
		System.out.println("Area of square with side = "+area);
		int area1 = me.calcRec(2,3);
		System.out.println("Area of rectangle is : "+area1);
		//int area1 = calcRec(2,3); not able to access
		//non-static members cant be accessed within a static context

	}

	public static int calcArea(int side) {
		int area = side * side;
		int area1 = me.calcRec(2, 10);
		System.out.println("Area : "+area1);
		return area;
	}
	
	public int calcRec(int len,int width) {
		int a = len * width;
		return a;
	}

}
