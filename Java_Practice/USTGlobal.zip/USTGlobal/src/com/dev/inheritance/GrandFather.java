package com.dev.inheritance;

public class GrandFather {

	static GrandFather gf = new GrandFather();
	String lastName = "Stark";
	String name = "Torrhen";
	

	public static void main(String[] args) {
		
		gf.printName();
	}
	
	public void printName() {
		
		System.out.println(name+" "+gf.lastName);
	}
	
	

}
