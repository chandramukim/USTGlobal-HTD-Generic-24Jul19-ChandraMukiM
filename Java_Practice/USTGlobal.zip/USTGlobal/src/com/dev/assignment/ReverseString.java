package com.dev.assignment;

public class ReverseString {
	public static void main(String[] args) {
		String str = "Hello";
		
		char[] ch = str.toCharArray();

		System.out.println("Original String");
		for(int i=0;i<ch.length;i++) {
			System.out.print(ch[i]);
		}
		
		System.out.println();
		
		
		System.out.println("Reversed String");
		for(int i=(ch.length)-1;i>=0;i--) {
			System.out.print(ch[i]);
		}
	}
}
