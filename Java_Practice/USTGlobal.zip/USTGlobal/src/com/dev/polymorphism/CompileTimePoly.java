package com.dev.polymorphism;

public class CompileTimePoly {
	
	public int addNum(int a,int b) {
		return (a+b);
	}
	
	public int addNum(int a,int b,int c) {
		return (a+b+c);
	}	
	
	public static void main(String[] args) {
		
		CompileTimePoly ctp = new CompileTimePoly();
		System.out.println("Addition of two number : "+ctp.addNum(10, 20));
		System.out.println("Addition of three number : "+ctp.addNum(10, 20,30));
		
	}

}
