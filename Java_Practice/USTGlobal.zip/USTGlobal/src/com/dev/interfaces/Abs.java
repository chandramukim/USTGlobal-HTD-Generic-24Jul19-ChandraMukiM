package com.dev.interfaces;

public interface Abs {
	public abstract void print();
	
	public static int a = 10;
	
	 public static void display() {
		System.out.println("hello");
	}

}
