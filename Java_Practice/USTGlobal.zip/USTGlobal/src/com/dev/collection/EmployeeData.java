package com.dev.collection;

public class EmployeeData {
	public static void main(String[] args) {
		EmpData ed = new EmpData();
		
		Employee e = new Employee();
		e.setName("Muki");
		e.setId(101);
		e.setEmail("muki123@gmail.com");
		e.setPassword("muki1998");
		e.setSalary(20000);
		
		Employee e1 = new Employee();
		e1.setName("Maya");
		e1.setId(102);
		e1.setEmail("maya9876@gmail.com");
		e1.setPassword("maya1999");
		e1.setSalary(30000);
		
		Employee e2 = new Employee();
		e2.setName("Neelu");
		e2.setId(103);
		e2.setEmail("neelu678@gmail.com");
		e2.setPassword("neelu123");
		e2.setSalary(40000);
		
		//adding
		boolean b1 = ed.addEmployee("1", e);
		System.out.println(b1);	
		boolean b = ed.addEmployee("2",e1);
		System.out.println(b);
		boolean b2 = ed.addEmployee("3", e2);
		System.out.println(b2);
		
		//retreiving
		Employee a = ed.getEmployee("2");
		System.out.println(a);
		
	
		//updating
		ed.updateEmployee(e1);
		System.out.println(ed.getEmployee("2"));
		
		//deleting
		boolean bool = ed.deleteEmployee(e2);
		System.out.println(bool);
		
	}

}
