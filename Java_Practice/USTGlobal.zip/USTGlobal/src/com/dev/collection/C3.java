package com.dev.collection;

import java.util.HashMap;

import com.dev.encapsulation.Dogs;

public class C3 {
	public static void main(String[] args) {
		HashMap<String, Dogs> hm = new HashMap<String, Dogs>();
		
		Dogs d = new Dogs();
		d.setAge(1);
		d.setBreed("husky");
		d.setColor("White");
		d.setName("Shiro");		
		
		Dogs d1 = new Dogs();
		d1.setAge(2);
		d1.setBreed("dalmation");
		d1.setColor("Black&White");
		d1.setName("Spike");
		
		
//		Dogs b = hm.put("1", d);
//		System.out.println(b);
		
		hm.put("1", d);
		hm.put("2",	d1);
		
		System.out.println(hm);
		
		System.out.println(hm.get("2"));
		
		//remove method
		Dogs f = hm.remove("1");
		//System.out.println(f);
		//System.out.println(hm);
		
		//containskey()
		System.out.println("Output of containsKey(): "+hm.containsKey("1"));
		
		//containsValue()
		System.out.println("Output of containsValue(): "+hm.containsValue(d1));
		
		//size()
		System.out.println("Output of size(): "+hm.size());
		
		//hm.clear();
		
		//isEmpty()
		System.out.println("Output of isEmpty(): "+hm.isEmpty());
		
	}
}
