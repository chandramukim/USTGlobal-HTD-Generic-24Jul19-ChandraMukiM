package com.dev.inheritance;

public class SuperClass {
	
	public SuperClass() {
		System.out.println("Running no-argument constructor");
	}
	
	public SuperClass(int i) {
		System.out.println("Running a constructor with int argument");
	}
	
	public SuperClass(double d) {
		System.out.println("Running a constructor with double argument");
	}
	
	public SuperClass(String s,long l) {
		System.out.println("Running a cosntructor with String and long argument");
	}
	
	public static void main(String[] args) {
	
		SuperClass ss = new SuperClass();
	}

}
