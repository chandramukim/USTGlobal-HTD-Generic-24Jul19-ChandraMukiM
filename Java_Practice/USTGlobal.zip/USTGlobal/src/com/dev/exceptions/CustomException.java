package com.dev.exceptions;

public class CustomException extends Exception{
	public CustomException() {
		System.out.println("CustomException");
	}
	
	public CustomException(int i) {
		System.out.println("Exception occured for integer");
	}
	
	public CustomException(String s) {
		System.out.println("Exception occured for string");
	}
	
	@Override
	public String getLocalizedMessage() {
		return "custom message";
		
	}
	
}


