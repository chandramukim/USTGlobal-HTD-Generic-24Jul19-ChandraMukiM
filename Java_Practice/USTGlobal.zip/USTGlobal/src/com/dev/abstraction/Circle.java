package com.dev.abstraction;

public abstract class Circle extends Shape{
	
	void shape() {
		System.out.println("Running shape() of Circle class");
	}
	
	
	
}
