package com.dev.abstraction;

public class Abstraction extends AbstractExample{
	
	public Abstraction() {
		super();
	}
	
	@Override
	void display() {
		System.out.println("Running implemented abstract method..");
	}
	
	public static void main(String[] args) {
		Abstraction a = new Abstraction();
		a.display();
		a.concreteMethod();
		
		
	}
}
