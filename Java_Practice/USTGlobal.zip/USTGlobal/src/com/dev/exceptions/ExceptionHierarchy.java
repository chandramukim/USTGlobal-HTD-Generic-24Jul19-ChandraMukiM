package com.dev.exceptions;

public class ExceptionHierarchy {
	public static void main(String[] args) {
		System.out.println("Main Started");
		test();//exception statement
		System.out.println("Main Ended");
	}
	
	public static void test() {
		try {
			StringBuffer sb = new StringBuffer(-1);//exception statement
		}catch(Exception e) {
			new CustomException().printStackTrace();
		}
	
	}
}
