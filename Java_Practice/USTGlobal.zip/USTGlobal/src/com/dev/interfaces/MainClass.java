package com.dev.interfaces;

public class MainClass implements Abs,InterfaceA {

	@Override
	public void print() {
		System.out.println("hello");
		
	}
	

	
}
