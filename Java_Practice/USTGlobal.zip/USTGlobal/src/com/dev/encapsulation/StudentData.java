package com.dev.encapsulation;

public class StudentData {
	public static void main(String[] args) {
		Student s = new Student();
		
		s.setRegno(101);
		s.setName("Muki");
		s.setEmail("muki123@gmail.com");
		s.setPass("9580");
		
		System.out.println("Name :"+s.getName());
		System.out.println("Registration num :"+s.getRegno());
		System.out.println("E-Mail :"+s.getEmail());
		
	}

}
