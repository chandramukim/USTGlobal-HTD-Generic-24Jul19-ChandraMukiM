package com.dev.collection;

public interface EmpInterface {
		
	boolean addEmployee(String s,Employee emp);
	Employee getEmployee(String s);
	void updateEmployee(Employee emp);
	boolean deleteEmployee(Employee emp);
}
