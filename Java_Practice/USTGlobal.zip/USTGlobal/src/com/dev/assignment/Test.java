package com.dev.assignment;

public class Test extends Demo {
	static int a = 40;
	public void m1()
	{
		int b=20;
		System.out.println(super.a + b );
		System.out.println(a+b);
	}
	public static void main(String[] args) {
		Test t = new Test();
		t.m1();
		StringBuffer sb = new StringBuffer("hello");
		sb = sb.append("world");
		
	}
}
