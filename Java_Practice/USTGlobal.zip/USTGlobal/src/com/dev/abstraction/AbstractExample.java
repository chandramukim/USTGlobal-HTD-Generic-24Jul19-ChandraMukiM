package com.dev.abstraction;

public abstract class AbstractExample {
		
	public AbstractExample() {
		System.out.println("Running abstract class constructor..");
	}
	
	//abstract method
	abstract void display();
	
	//concrete method
	public void concreteMethod() {
		System.out.println("Running a concrete method..");
	}

}
