package com.dev.interfaces;

public interface InterfaceA extends Abs{

}
