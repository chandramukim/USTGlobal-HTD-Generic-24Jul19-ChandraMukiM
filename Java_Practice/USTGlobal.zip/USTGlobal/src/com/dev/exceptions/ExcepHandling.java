package com.dev.exceptions;

public class ExcepHandling {
	public static void main(String[] args) throws CustomException{
		
		divideNum(10,0);
	}
	
	public static int divideNum(int i,int j) {
		int res = i/j;
		return res;
	}

}
