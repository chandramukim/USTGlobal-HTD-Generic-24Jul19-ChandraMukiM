package com.dev.inheritance;

public class AddTwoNum {
	int a = 10;
	int b = 20;
	
	public int addNumbers() {
		return (a+b);
	}
	
	public void printResult() {
		System.out.println("The addition of two numbers is :"+addNumbers());
	}
	
	public static void main(String[] args) {
		AddTwoNum d = new AddTwoNum();
		d.printResult();
	}
}
