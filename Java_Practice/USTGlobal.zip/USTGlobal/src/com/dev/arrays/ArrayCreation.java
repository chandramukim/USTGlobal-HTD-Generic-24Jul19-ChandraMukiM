package com.dev.arrays;

public class ArrayCreation {
	public static void main(String[] args) {
		//Declaring and creating an integer array
		int[] intArr = new int[3];
		
		//Initializing th einteger array
		intArr[0] = 10;
		intArr[1] = 20;
		intArr[2] = 30;
		
		for(int i=0;i<intArr.length;) {
			System.out.println("hi");
		}
		int res = intArr[0] * 3;
		System.out.println(res);
		res = intArr[1] * 3;
		System.out.println(res);
		res = intArr[2] * 3;
		System.out.println(res);
		
		//Declaring and  intializing na integer array
		int[] intArr2 = {10,20,30,40};
		System.out.println(intArr[2]);
		System.out.println("Length of the 2nd array is: "+intArr.length);
	}

}
