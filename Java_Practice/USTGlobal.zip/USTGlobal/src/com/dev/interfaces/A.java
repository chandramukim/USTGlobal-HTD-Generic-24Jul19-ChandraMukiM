package com.dev.interfaces;

public interface A {
	abstract void m1();
}
