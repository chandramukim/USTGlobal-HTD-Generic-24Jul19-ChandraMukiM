package com.dev.inheritance;

public class Father extends GrandFather {
	
	static Father f = new Father();
	String name = "Eddard";//re-initialized
	
	@Override
	public void printName() {
		//String name = "Eddard";
		System.out.println(name+" "+super.name+" "+f.lastName);
		//System.out.println(name+" "+f.name+" "+f.lastName); 
		//for this we have to decalre name variable globally.
		super.printName();
	}
	
	public static void main(String[] args) {
		f.printName();
		Father f1 = new Father();
	
	}
	
}
