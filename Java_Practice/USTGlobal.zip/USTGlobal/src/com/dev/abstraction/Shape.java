package com.dev.abstraction;

public abstract class Shape {
	
	abstract void draw();

}
