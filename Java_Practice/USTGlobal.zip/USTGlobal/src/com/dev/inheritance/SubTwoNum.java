package com.dev.inheritance;

public class SubTwoNum {
	int a = 20;
	int b = 30;
	
	public int subnumbers() {
		int c;
		c=b-a;
		return c;
	}
	
	public static void main(String[] args) {
		SubTwoNum s = new SubTwoNum();
		System.out.println("The difference of two numbers is: "+s.subnumbers());
	}
}
