package com.dev.encapsulation;

public class AnimalData {
	
	public static void main(String[] args) {
		//for Dogs
		Dogs d = new Dogs();
		Dogs d1 = new Dogs();
		
		//setting the values
		d.setAge(1);
		d.setBreed("Husky");
		d.setColor("White&Brown");
		d.setName("Scooby");		
	
		
		//setting the values
		d1.setAge(2);
		d1.setBreed("Pit bull");
		d1.setColor("Grey");
		d1.setName("Spike");
				
		//getting the values using getters
		
		
		
		//for Cats
//		Cats c = new Cats();
//		Cats c1= new Cats();
//		
//		c.setName("kyunni");
//		c.setAge(2);
//		c.setColor("Brown");
//		
//
//		
//		c1.setName("Bell");
//		c1.setAge(1);
//		c1.setColor("Black");
//		
	
		Dogs[] dog = {d,d1};
		//Cats[] cat = {c,c1};
		
		for(int i=0;i<dog.length;i++) {
			System.out.println("Name :"+dog[i].getName());
			System.out.println("Age :"+dog[i].getAge());
			System.out.println("Breed :"+dog[i].getBreed());
			System.out.println("Color :"+dog[i].getColor());
			System.out.println("==============================");
		}
		
//		for(int i=0;i<cat.length;i++) {
//			System.out.println("Name :"+cat[i].getName());
//			System.out.println("Age :"+cat[i].getAge());
//			System.out.println("Color :"+cat[i].getColor());
//			System.out.println("==============================");
//		}

	}
}
