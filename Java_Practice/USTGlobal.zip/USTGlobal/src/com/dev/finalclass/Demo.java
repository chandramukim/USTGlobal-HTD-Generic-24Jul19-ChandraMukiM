package com.dev.finalclass;

public class Demo {
	final static int I = 10;
	
	public final void m1() {
		System.out.println("Inside a final method");
	}
}
