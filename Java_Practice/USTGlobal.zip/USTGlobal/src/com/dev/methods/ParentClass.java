package com.dev.methods;

public class ParentClass {
	int a ;
	ParentClass(){
		this.a = 10;
	}
	String name = "muki";
	
	
//	public final void print()--> final method cant be overriden
//	public static void print()-->static methods cant be overriden
	public void print() {
		int age = 21;
		System.out.println("My name is "+name+" and my age is "+age);
		
	}

}
