package com.dev.objectmethods;

public class Demo {
	public static int i = 10;
	
	public static void m1() {
		System.out.println("Running m1()...");
	}
}
