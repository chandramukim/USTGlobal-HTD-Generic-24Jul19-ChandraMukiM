package com.dev.threads;

public class T1 {
	public static void main(String[] args) {
		System.out.println("Main Started..");
		
		new T2().start();
		new Thread(new T3()).start();
		for(int i=1; i<=10; i++) {
			System.out.println("i = "+i);
		}
		
		System.out.println("Main Ended");
	}
}
