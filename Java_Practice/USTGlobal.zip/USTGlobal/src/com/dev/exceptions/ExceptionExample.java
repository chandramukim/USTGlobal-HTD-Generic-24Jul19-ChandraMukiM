package com.dev.exceptions;

public class ExceptionExample {
	public static void main(String[] args) {
	
		try {
			
			test();
			System.out.println("No exception  for test()");
			int res = divide(10,0);
			System.out.println("No exception for divide(int,int)");
		
		}catch(NegativeArraySizeException e) {
			
			System.err.println(e.getMessage());
		
		}catch(ArithmeticException e) {
			
			System.err.println(e.getMessage());
		}
		
		
		
	}
	
	public static void test() {
		StringBuffer sb = new StringBuffer(1);
	}

	public static int divide(int a,int b) {
		return (a/b);
	}
}


