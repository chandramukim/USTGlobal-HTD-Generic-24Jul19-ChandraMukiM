package com.dev.collection;

import java.util.HashSet;

import com.dev.encapsulation.Dogs;

public class C1 {
	public static void main(String[] args) {
		HashSet<Dogs> hs = new HashSet<Dogs>();
		Dogs d = new Dogs();
		d.setAge(1);
		d.setBreed("husky");
		d.setColor("White");
		d.setName("Shiro");		
		
		Dogs d1 = new Dogs();
		d1.setAge(2);
		d1.setBreed("dalmation");
		d1.setColor("Black&White");
		d1.setName("Spike");
		
		boolean b = hs.add(d);
		boolean b1 = hs.add(d1);
		System.out.println("Output of add(): "+b+" "+b1);
		System.out.println(hs);
		
		boolean b2 = hs.remove(d);
		System.out.println("Output of remove(): "+b2);
		System.out.println(hs);
		
		System.out.println("Output of contains(d): "+hs.contains(d));
		System.out.println("Output of contains(d1): "+hs.contains(d1));
		
		
		System.out.println("Output of size(): "+hs.size());
		
		hs.clear();
		System.out.println("Size of HashSet after clear: "+hs.size());
		
		System.out.println("Output for isEmpty(): "+hs.isEmpty());
	}

}
