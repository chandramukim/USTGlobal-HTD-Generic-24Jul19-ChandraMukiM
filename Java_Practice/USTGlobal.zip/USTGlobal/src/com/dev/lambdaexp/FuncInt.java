package com.dev.lambdaexp;

@FunctionalInterface
public interface FuncInt {
	public void display();
}
