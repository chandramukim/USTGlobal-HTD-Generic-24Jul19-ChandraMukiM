package com.dev.assignment;

public class Demo {
	 int a = 10;
	public static void main(String[] args) {
//		int binary = 0b10;
//		int octal=010;
//		int decimal = 10;
//		int hexa = 0x1110;
//		
//		System.out.println(binary+" "+octal+" "+decimal+" "+hexa);
		
//		int x=10;
//		int y=11;
//	
//		System.out.println((x++ + --y));//20
		
		char array_variable [] = new char[10];
	    for (int i = 0; i < 10; ++i) {
                array_variable[i] = 'i';
                System.out.print(array_variable[i] + "" );
                i++;
            }
	    int w = (int)888.8;
	    byte x = (byte)100L;
	    long y = (byte)100;
	    byte z = (byte)100L;
	    
	    System.out.println(w+" "+x+" "+y+" "+z);
	}


}
