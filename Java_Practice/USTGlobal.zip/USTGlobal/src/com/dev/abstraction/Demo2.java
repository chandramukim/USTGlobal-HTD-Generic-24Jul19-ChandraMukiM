package com.dev.abstraction;

import com.dev.demo.Demo1;

public class Demo2 extends Demo1{
	public static void main(String[] args) {
		Demo1 d1 = new Demo1();
		
	}
}
