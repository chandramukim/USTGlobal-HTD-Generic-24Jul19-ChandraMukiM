package com.dev.abstraction;

public class Rectangle extends Shape{
	
	@Override
	void draw() {
		System.out.println("Running draw method of Rectangle class");
	}
}
