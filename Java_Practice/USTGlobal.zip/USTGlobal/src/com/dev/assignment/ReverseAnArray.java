package com.dev.assignment;

import java.util.Scanner;

public class ReverseAnArray {
	public static void main(String[] args) {
		int[] arrayEle = new int[5];
		Scanner s = new Scanner(System.in);
		
		System.out.println("Enter the array elements");
		for(int i=0; i<arrayEle.length;i++) {
			arrayEle[i]=s.nextInt();
		}
	
		System.out.println("The array elements before reversing");
		System.out.println("====================================");
		System.out.print("[");
		for(int i=0; i<arrayEle.length;i++) {
			System.out.print(arrayEle[i]+"\t");
		}
		System.out.println("]");
		System.out.println();
		
		System.out.println("Array elements after Reversing");
		System.out.println("=================================");
		System.out.print("[");
		for(int i=(arrayEle.length)-1 ;i>=0;i--) {
			System.out.print(arrayEle[i]+"\t");
		}
		System.out.println("]");
	}

}
