package com.dev.methods;

import static com.dev.objectmethods.Demo.*;


public class Test{
	public static void main(String[] args) {
		System.out.println(i);
	}
}
