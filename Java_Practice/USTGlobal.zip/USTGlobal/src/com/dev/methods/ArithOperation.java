package com.dev.methods;

import java.util.Scanner;

public class ArithOperation {
		
	ArithOperation ao = new ArithOperation();
	
	//Overloading add() method
	public int add(int a,int b) {
		return (a+b);
	}
	
	public int add(int a,int b,int c) {
		return (a+b+c);
	}
	
	public int add(int a,int b,int c,int d) {
		return (a+b+c+d);
	}
	
	//Overlaoded sub() method
	public int sub(int a, int b) {
		return (a-b);
	}	
	
	public int sub(int a,int b,int c) {
		return (a-b-c);
	}
	
	public int sub(int a,int b,int c,int d) {
		return (a-b-c-d);
	}
	
	//Overloaded mul() method
	public int mul(int a,int b) {
		return (a*b);
	}
	
	public int mul(int a,int b,int c) {
		return (a*b*c);
	}
	
	public int mul(int a,int b,int c,int d) {
		return (a*b*c*d);
	}
	
	//Overloaded div() method
	public double div(int a,int b) {
		return (a/b);
	}
	
//	public double div(int a,int b,int c) {
//		return (a/b/c);
	
	
//	}
	
	public double div(int a,int b,int c,int d) {
		return (a/b/c/d);
	}
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		ArithOperation ao = new ArithOperation();
		
		System.out.println("1.Addition\n2.Substraction\n3.Multiplication\n4.Division\n5.exit");
		System.out.println("Enter your choice");
		int ch = sc.nextInt();
		System.out.println("On how many value do u want to perform the operation? ");
		int vari = sc.nextInt();
		
		switch(vari) {
		case 1: System.out.println("Enter two values");
				int a = sc.nextInt();
				int b = sc.nextInt();
				System.out.println("Addition of "+a+" and "+b+" is: "+ao.add(a,b));
				break;
		case 2: System.out.println("Enter three values");
				a = sc.nextInt();
				b = sc.nextInt();
				int c = sc.nextInt();
				System.out.println("Addition of "+a+" "+b+" and "+c+" is: "+ao.add(a, b, c));
				break;
		case 3: System.out.println("Enter four values");
				a = sc.nextInt();
				b = sc.nextInt();
				c = sc.nextInt();
				int d = sc.nextInt();
				System.out.println("Addition of "+a+" "+b+" "+c+" and "+d+" is: "+ao.add(a, b, c, d));
		case 4: System.out.println("Enter two values");
				a = sc.nextInt();
				b = sc.nextInt();
				System.out.println("Substraction of "+a+" and "+b+" is: "+ao.sub(a,b));
				break;
		case 5: System.out.println("Enter three values");
				a = sc.nextInt();
				b = sc.nextInt();
				c = sc.nextInt();
				System.out.println("Substraction of "+a+" "+b+" and "+c+" is: "+ao.sub(a, b, c));
				break;
		case 6: System.out.println("Enter four values");
				a = sc.nextInt();
				b = sc.nextInt();
				c = sc.nextInt();
				d = sc.nextInt();
				System.out.println("Substraction of "+a+" "+b+" "+c+" and "+d+" is: "+ao.sub(a, b, c, d));
				break;
		case 7: System.out.println("Enter two values");
				a = sc.nextInt();
				b = sc.nextInt();
				System.out.println("Product of "+a+" and "+b+" is: "+ao.mul(a,b));
				break;
		case 8: System.out.println("Enter three values");
				a = sc.nextInt();
				b = sc.nextInt();
				c = sc.nextInt();
				System.out.println("Product of "+a+" "+b+" and "+c+" is: "+ao.mul(a, b, c));
				break;
		case 9: System.out.println("Enter four values");
				a = sc.nextInt();
				b = sc.nextInt();
				c = sc.nextInt();
				d = sc.nextInt();
				System.out.println("Product of "+a+" "+b+" "+c+" and "+d+" is: "+ao.mul(a, b, c, d));
		case 10: System.out.println("Enter two values");
				 a = sc.nextInt();
				 b = sc.nextInt();
				 System.out.println("Division of "+a+" and "+b+" is: "+ao.div(a,b));
				 break;
//		case 11: System.out.println("Enter three values");
//				 a = sc.nextInt();
//				 b = sc.nextInt();
//				 c = sc.nextInt();
//				 System.out.println("Division of "+a+" "+b+" and "+c+" is: "+ao.div(a, b, c));
//				 break;
		case 12: System.out.println("Enter four values");
				 a = sc.nextInt();
				 b = sc.nextInt();
				 c = sc.nextInt();
				 d = sc.nextInt();
				 System.out.println("Product of "+a+" "+b+" "+c+" and "+d+" is: "+ao.mul(a, b, c, d));
				 break;
		case 13: System.exit(0);
				 break;
		}
	}
}
