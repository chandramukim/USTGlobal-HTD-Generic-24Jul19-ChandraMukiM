package com.dev.exceptions;

public class ExceptionHaandling {
	public static void main(String[] args) throws CustomException {
		try {
			test();
		}catch(CustomException e) {
			System.out.println("Exception Occured");
			//e.printStackTrace();
			System.out.println("getLocalizedException: "+new CustomException().getLocalizedMessage());
			
		}finally {
			System.out.println("This is finally block");
		}
		//System.out.println("code after exception");
		
		//test(); either surround by try-catch block else add throws declaration
	}
	
	public static void test() throws CustomException {
		//StringBuffer sb = new StringBuffer(-1);exception statement
		int a = -1;
		if(a<0) {
			throw new CustomException();
		}
		System.out.println("A =" +a);
	}
}
