package com.dev.finalclass;

public final class Test extends Demo {
	public static void main(String[] args) {
		Demo d = new Demo();
	
//		public final void m1() {
//		  System.out.println("hi");
//		}
		  
		
		d.m1();
	}
	
}
