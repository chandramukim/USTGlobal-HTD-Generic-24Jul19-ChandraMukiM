package com.dev.arrays;

public class ArrayIndex {
	public static void main(String[] args) {
		//declaring and creating an integer array
        int[] intArr = new int[5];
        int index = 3;
		
		//intializing the value to the array
		intArr[0] = 21;
		intArr[1] = 22;
		intArr[2] = 23;
		intArr[3] = 24;
		intArr[4] = 25;
		
		//Checking whether the specified index is present
		if(index<intArr.length) {
			System.out.println(index+" is a valid index");
			for(int i=0; i<=index ; i++) {
				System.out.println(intArr[i]);
			}
		}
		else if(index<0 || index>=index) {
			System.out.println(index+" is not a valid index please enter a valid index");
		}
	}

}
