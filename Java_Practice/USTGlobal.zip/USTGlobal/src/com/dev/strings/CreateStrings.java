package com.dev.strings;

public class CreateStrings {
	public static void main(String[] args) {
		
		String str;//Declaring a string variable
		str = "Hello";//Initializing string variable str
		
		String str1 = "Java";//Declaring and initializing string variable str
		
		String str2 = new String("Hello Java");//creating a string using new keyword
		
		//String Builder and String Buffer classes
		StringBuffer st = new StringBuffer("Hello");
		StringBuilder sb = new StringBuilder("World");
		System.out.println(st+" "+sb);
	
	
	
		
	}

}
