package com.dev.methods;

public class MethodAccess {
	public static void main(String[] args) {
		MethodExample me = new MethodExample();
		int area = MethodExample.calcArea(6);
		System.out.println("Area of square = "+area);
		int area1 = me.calcRec(2, 9);
		System.out.println("Area of rectangle is : "+area1);
		String s = "hello";
		String s1 = "hello";
		
		System.out.println(s=s1);
	}
}
