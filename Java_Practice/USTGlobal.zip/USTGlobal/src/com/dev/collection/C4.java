package com.dev.collection;

import java.util.TreeSet;

import com.dev.encapsulation.Dogs;

public class C4 {
	public static void main(String[] args) {
		TreeSet<Dogs> ts = new TreeSet<Dogs>();
		
		Dogs d = new Dogs();
		d.setAge(1);
		d.setBreed("husky");
		d.setColor("White");
		d.setName("Shiro");		
		
		Dogs d1 = new Dogs();
		d1.setAge(2);
		d1.setBreed("dalmation");
		d1.setColor("Black&White");
	
		ts.add(d);
		ts.add(d1);
		System.out.println(ts);
	}
}
