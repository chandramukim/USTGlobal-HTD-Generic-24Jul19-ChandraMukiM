package com.dev.strings;

import java.net.SocketTimeoutException;

public class StringMethods {
	public static void main(String[] args) {
		String str = "Hello World";
		String str1 = "hello World";

		int len = str.length();//length method
		System.out.println(len);

		char[] ch = str.toCharArray();// toCharArray method
		System.out.println(ch);

		System.out.println(len);

		char c = str.charAt(6);//charAt method
		System.out.println(c);

		boolean bool = str.equals(str1);//equals method
		System.out.println(bool);

		//equalsIgnoreCase() method
		boolean b = str.equalsIgnoreCase(str1);
		System.out.println(b);

		//contains() method
		boolean bo = str.contains("Hell");
		System.out.println(bo);

		//replace() method
		String s = str.replace('H','Z');
		System.out.println(s);

		//indexOf() method
		int i = str1.indexOf('w');
		int i1 = s.indexOf('Z');
		System.out.println(i);
		System.out.println(i1);
		
		
		//toUpperCase() method and toLowerCase()
		System.out.println(str.replace('H','Z'));
		String str2 = str.toUpperCase();
		System.out.println(str2);
		
		
		String str3 = str2.toLowerCase();
		System.out.println(str3);
		
		String s1 = "Welcome to Jspiders";
		String a = s1.substring(6);
		System.out.println("Output for subString(int) is: "+a);
		
		String ce = s1.substring(3,7);
		System.out.println("Output for subString(int,int) is: "+ce);
	}

}
