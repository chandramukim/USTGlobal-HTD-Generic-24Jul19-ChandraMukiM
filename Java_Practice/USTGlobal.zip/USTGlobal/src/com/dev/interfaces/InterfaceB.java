package com.dev.interfaces;

public interface InterfaceB extends Abs,InterfaceA {

	
	
}
