package com.dev.assignment;

public class Sum {
	public static void main(String[] args) {
		int[] a = {1,2,3,4,5,6,7};
		int num = (a.length)/2;
		int i=0, j=a[num] ,k=(a.length)-2;
		
		System.out.println(a[num]);
		
		int sum = a[i]+ j+ a[k];
		
		System.out.println("Sum: "+sum);
		

	}

}
