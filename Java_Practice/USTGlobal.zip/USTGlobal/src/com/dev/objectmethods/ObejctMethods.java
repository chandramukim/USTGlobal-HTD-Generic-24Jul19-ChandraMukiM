package com.dev.objectmethods;

public class ObejctMethods {
	
	public static void main(String[] args) {
		Dogs d = new Dogs();
		Dogs d1 = new Dogs();
	
		
		System.out.println(d.getClass());//tells which class the particular object is present
		System.out.println(d1.getClass());
	}
	
}
