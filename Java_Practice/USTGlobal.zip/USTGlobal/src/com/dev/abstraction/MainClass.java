package com.dev.abstraction;

public class MainClass {
	public static void main(String[] args) {
		Rectangle r = new Rectangle();
		r.draw();
		Sphere s = new Sphere();
		s.draw();
		s.shape();
		
	}
}
