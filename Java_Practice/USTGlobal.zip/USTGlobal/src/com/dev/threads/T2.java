package com.dev.threads;

public class T2 extends Thread{
	
	@Override
	public void run() {
		System.out.println("T2 Thread Started...");
		
		for(int j=1; j<=10; j++) {
			System.out.println("j ="+j);
		}
		
		System.out.println("T2 Thread Ended");
	}
	
}
