package com.dev.arrays;

public class MiddleElement {
	public static void main(String[] args) {
		int[] intArr = new int[10];

		for(int i = 0;i<intArr.length;i++) {
			intArr[i]=10*(i+1);
			System.out.println(intArr[i]);
		}
		
		int middle = (intArr.length)/2;
		System.out.println("The middle element of the array is :"+intArr[middle]);

	}
}
