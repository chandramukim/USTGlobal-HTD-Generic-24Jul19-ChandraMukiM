package com.dev.demo;

public class Demo1 {
	protected int x = 10;
}
