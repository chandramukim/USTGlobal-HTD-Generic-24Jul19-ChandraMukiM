package com.dev.arrays;

public class CreatingArray {
	public static void main(String[] args) {
		//Declaring int,char and byte array
		int []intArr;
		char[] charr;
		byte byteArr[];
		
		//Creating int,char and byte array
		intArr = new int[5];
		charr = new char[5];
		byteArr = new byte[5];
		
		//Adding elements to integerArray
		intArr[0] = 10;
		intArr[1] = 20;
		intArr[2] = 30;
		intArr[3] = 40;
		intArr[4] = 50;
		
		//Adding elements to charArray
		charr[0] = 'A';
		charr[1] = 'B';
		charr[2] = 'C'; 
		charr[3] = 'D';
		charr[4] = 'E';
		
		//Adding elemetns to byteArray
		byteArr[0] = 1;
		byteArr[1] = 2;
		byteArr[2] = 3;
		byteArr[3] = 4;
		byteArr[4] = 5;
		
		//Performing some arithmetic operation on intArray
		System.out.println("IntegerArray");
		System.out.println("***************");
		
		int res = intArr[0] * 3;
		System.out.println(res);
		res = intArr[1] * 3;
		System.out.println(res);
		res = intArr[2] * 3;
		System.out.println(res);
		res = intArr[3] * 3;
		System.out.println(res);
		res = intArr[4] * 3;
		System.out.println(res);
		System.out.println();
		
		
		//Performing some arithmetic operation on byteArray
		System.out.println("ByteArray");
		System.out.println("**************");
		
		int result = byteArr[0] + 100;
		System.out.println(result);
		result = byteArr[1] + 100;
		System.out.println(result);
		result = byteArr[2] + 100;
		System.out.println(result);
		result = byteArr[3] + 100;
		System.out.println(result);
		result = byteArr[4] + 100;
		System.out.println(result);
		
	}
}
