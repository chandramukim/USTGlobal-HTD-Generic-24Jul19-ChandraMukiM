package com.dev.inheritance;

public class Daughter extends Father {
	static Daughter d = new Daughter();
	
	public void printName() {
		String name = "Sansa";
		System.out.println(name+" "+super.name+" "+d.lastName);// here f.name uses eddard
		super.printName();
	}
	
	public static void main(String[] args) {
		d.printName();
	}
}
