/*
 * this program demonstrates constructor concept and constructor overloading
 * 
 */
package com.dev.constructors;

public class ConstructorMethod {
	
	//no-argument constructor
	public ConstructorMethod() {
		System.out.println("This a no-argument constructor");
	}
	
	
	//parameterized constructor with one integer argument
	public ConstructorMethod(int i) {
		System.out.println("Within a parameterized constructor with one Integer as argument");
	}
	
	
	//two-argument constructor with one string argument
	public ConstructorMethod(String s) {
		System.out.println("This constructor takes String as arguments");
	}
	
	
	//two-argument constructor which takes double and char as arguments
	public ConstructorMethod( double d, char s) {
		System.out.println("This constructor takes Double and Char as arguments");
	}
	
	
	//two-argument constructor which takes char and double as arguments
	public ConstructorMethod(char s, double d) {
		System.out.println("This constructor takes Char and Double as arguments");
	}
	
	//main method: here we are creating objects to invoke the constructors based on the arguments passed
	public static void main(String[] args) {
		ConstructorMethod cm = new ConstructorMethod('c',3.13);
		//ConstructorMethod cm1 = new ConstructorMethod();
		//ConstructorMethod cm2 = new ConstructorMethod("muki");
		//ConstructorMethod cm3 = new ConstructorMethod(30.98,'m');
	}

}
