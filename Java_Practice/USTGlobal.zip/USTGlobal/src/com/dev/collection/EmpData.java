package com.dev.collection;

import java.util.HashMap;
import java.util.Scanner;

public class EmpData implements EmpInterface{
	
	HashMap<String, Employee> hm = new HashMap<String, Employee>();
	Scanner s = new Scanner(System.in);

	@Override
	public boolean addEmployee(String s,Employee emp) {
		
		if(emp!=null) {
			hm.put(s, emp);
			return true;
		}
		return false;
	}

	@Override
	public Employee getEmployee(String s) {
		
		return hm.get(s);
	}

	@Override
	public void updateEmployee(Employee emp) {
		
		if(emp!=null) {
			System.out.println("What to update?");
			System.out.println("1.Name\n2.ID\n3.Email\n4.Password\n5.Salary\n");
			int ch = s.nextInt();
			
			switch(ch) {
			case 1: System.out.println("Enter Name to update");
					String name = s.next();
					emp.setName(name);
					break;
			case 2: System.out.println("Enter id to update");
					int id = s.nextInt();
					emp.setId(id);
					break;
			case 3: System.out.println("Enter email to update");
					String email = s.next();
					emp.setEmail(email);
					break;
			case 4: System.out.println("Enter Password to update");
					String pass = s.next();
					emp.setPassword(pass);
					break;
			case 5: System.out.println("Enter Salary to update");
					int salary = s.nextInt();
					emp.setSalary(salary);
					break;
			default: System.out.println("Invalid choise:(");
			}
		}
	}

	@Override
	public boolean deleteEmployee(Employee emp) {
		if(emp!=null) {
			hm.remove(emp);
			return true;
		}
		return false;
	}

	
	


}
