package com.dev.inheritance;

public class SubClass extends SuperClass {
	
	public SubClass() {
		super();
	}
	
	public static void main(String[] args) {
		SubClass sc = new SubClass();
	}

}
